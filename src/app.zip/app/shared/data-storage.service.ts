import { Injectable } from '@angular/core';
import {Http, Response} from "@angular/http";
import {ActivatedRoute, Router} from "@angular/router";
import {RecipeService} from "../recipes/recipe.service";
import {Recipe} from "../recipes/recipe.model";
import "rxjs/Rx";
import {AuthService} from "../auth.service";

@Injectable()
export class DataStorageService {

  constructor( private http: Http,
               private router: Router,
               private route: ActivatedRoute,
               private RecipeService: RecipeService,
               private authService: AuthService) {}


  saveRecipes(){
    const token= this.authService.getTokecn();
    console.log("put Metode"+this.RecipeService.getRecipes()[2].ingredients);

    return this.http.put('https://recipes-ng.firebaseio.com/data.json?auth=' + token, this.RecipeService.getRecipes());

  }
  getRecipes(){

    const token= this.authService.getTokecn();

    return this.http.get('https://recipes-ng.firebaseio.com/data.json?auth='+ token).map(
      (response: Response) =>{
        const recipes: Recipe[] = response.json();
        for (let recipe of recipes){
          if(!recipe['ingredients']){
            recipe['ingredients'] = [];
          }
        }
        return recipes;
      }
    )
      .subscribe(
      (recipes: Recipe[]) =>{
        this.RecipeService.setRecipes(recipes);
      }

    );
  }

}
